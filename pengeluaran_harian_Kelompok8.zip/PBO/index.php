<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "pbo";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $jumlah = mysqli_real_escape_string($conn, $_POST['jumlah']);
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);


    $queryUser = "SELECT id FROM users WHERE username = '$username'";
    $resultUser = mysqli_query($conn, $queryUser);
    $user = mysqli_fetch_assoc($resultUser);
    $userId = $user['id'];

    $query = "INSERT INTO pengeluaran (nama, kategori, jumlah, tanggal, keterangan, user_id) 
              VALUES ('$nama', '$kategori', '$jumlah', '$tanggal', '$keterangan', '$userId')";
    mysqli_query($conn, $query);
    header('Location: index.php');
}


if (isset($_GET['hapus'])) {
    $id = mysqli_real_escape_string($conn, $_GET['hapus']);
    $query = "DELETE FROM pengeluaran WHERE id = $id";
    mysqli_query($conn, $query);
    header('Location: index.php');
}

if (isset($_POST['hapusSemua'])) {
    $query = "DELETE FROM pengeluaran";
    mysqli_query($conn, $query);
    header('Location: index.php');
}

$queryUser = "SELECT id FROM users WHERE username = '$username'";
$resultUser = mysqli_query($conn, $queryUser);

if ($resultUser && mysqli_num_rows($resultUser) > 0) {
    $user = mysqli_fetch_assoc($resultUser);
    $userId = $user['id'];
} else {
    echo "User tidak ditemukan!";
    exit();
}


$result = mysqli_query($conn, "SELECT * FROM pengeluaran WHERE user_id = '$userId'");
$totalPengeluaran = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(jumlah) AS total FROM pengeluaran WHERE user_id = '$userId'"))['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catatan Pengeluaran Harian</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 0;
        }

        h1, h2, h3 {
            text-align: center;
            margin: 20px 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
        }

        input, select, textarea {
            width: 100%;
            padding: 8px;
            font-size: 14px;
            border-radius: 5px;
            border: 1px solid #ddd;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        button:active {
            transform: scale(1); 
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            box-sizing: border-box;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .total-row {
            font-weight: bold;
            background-color: #f1f1f1;
        }

        .button-group {
            text-align: center;
            margin-top: 20px;
        }

        .button-group button {
            margin: 5px;
            background-color: #28a745;
        }

        .button-group button:hover {
            background-color: #218838;
        }

        h1 {
            background-color: #007bff;
            color: white;
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 10px 10px 0 0;
        }

        button.logout {
            background-color: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            position: absolute;
            top: 20px;
            right: 20px;
        }

        button.logout:hover {
            background-color: #c82333;
        }

        .button-group button {
            display: inline-block;
            margin: 5px;
        }

        #button-container {
            text-align: center; 
            margin-top: 20px; 
        }

        #button-container button {
            padding: 10px 20px; 
            background-color: #ff4d4d; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            font-size: 16px; 
            cursor: pointer; 
            transition: all 0.3s ease; 
        }

        #button-container button:hover {
            background-color: #e60000; 
            transform: scale(1.05); 
        }

        #button-container button:active {
            transform: scale(1); 
        }

        #charts {
            display: flex;
            justify-content: center; 
            gap: 20px; 
            flex-wrap: wrap; 
            width: 60%; 
            margin: 60px auto; 
        }

        #charts canvas {
            flex: 1 1 calc(45% - 20px); 
            max-width: 100%;
            height: auto;
            border-radius: 10px; 
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); 
            transition: transform 0.3s ease, box-shadow 0.3s ease; 
        }

    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <a href="logout.php">
            <button class="logout">Logout</button>
        </a>

        <h1>Selamat datang, <?= $username ?>! Catat Pengeluaran Anda</h1>
        <form action="" method="POST">
            <div class="form-group">
                <label for="nama">Nama Pengeluaran</label>
                <input type="text" name="nama" id="nama" required>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori</label>
                <select name="kategori" id="kategori" required>
                    <option value="">Pilih Kategori</option>
                    <option value="Makanan">Makanan</option>
                    <option value="Transportasi">Transportasi</option>
                    <option value="Hiburan">Hiburan</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
            </div>
            <div class="form-group">
                <label for="jumlah">Jumlah (Rp)</label>
                <input type="number" name="jumlah" id="jumlah" required>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" required>
            </div>
            <div class="form-group">
                <label for="keterangan">Keterangan</label>
                <textarea name="keterangan" id="keterangan" rows="3"></textarea>
            </div>
            <button type="submit" name="tambah">Tambah Pengeluaran</button>
        </form>

        
        <h2>Data Pengeluaran</h2>
        <table id="dataTable">
            <thead>
                <tr>
                    <th>Nama Pengeluaran</th>
                    <th>Kategori</th>
                    <th>Jumlah (Rp)</th>
                    <th>Tanggal</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr class="dataRow" data-kategori="<?= $row['kategori'] ?>">
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['kategori'] ?></td>
                    <td>Rp <?= number_format($row['jumlah'], 0, ',', '.') ?></td>
                    <td><?= $row['tanggal'] ?></td>
                    <td><?= $row['keterangan'] ?></td>
                    <td>
                        <a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h3 class="total-row">Total Pengeluaran: Rp <?= number_format($totalPengeluaran, 0, ',', '.') ?></h3>

        <div class="button-group">
            <form action="" method="POST">
                <button type="submit" name="hapusSemua">Hapus Semua</button>
            </form>
            <button type="button" onclick="filterCategory()">Filter</button>
            <button type="button" onclick="resetFilters()">Filter Reset</button>

            <button type="button" onclick="showCSVForm()">Simpan ke CSV</button>

            <form id="csvForm" style="display:none;">
                <label for="filename">Nama File CSV:</label>
                <input type="text" name="filename" id="filename" required>
                <button type="button" onclick="downloadCSV()">Download CSV</button>
                <button type="button" onclick="cancelCSV()">Batal</button> 
            </form>

            <button type="button" onclick="showCharts()">Grafik</button>

            <div id="charts" style="display:none;">
                <h3>Grafik Pengeluaran Berdasarkan Kategori</h3>
                <canvas id="pieChart"></canvas>

                <h3>Grafik Pengeluaran Berdasarkan Tanggal</h3>
                <canvas id="barChart"></canvas>

                <div id="button-container">
                    <button type="button" onclick="cancelGrafik()">Batal</button>
                </div>
            </div>
        </div>

    <script>
        function filterCategory() {
            let category = prompt("Masukkan kategori untuk filter (Makanan, Transportasi, Hiburan, Lainnya):");
            if (category) {
                let rows = document.querySelectorAll('.dataRow');
                rows.forEach(row => {
                    if (row.getAttribute('data-kategori') !== category && category !== "") {
                        row.style.display = "none";
                    } else {
                        row.style.display = "";
                    }
                });
            }
        }

        function resetFilters() {
            let rows = document.querySelectorAll('.dataRow');
            rows.forEach(row => {
                row.style.display = "";
            });
        }

        function showCSVForm() {
            document.getElementById('csvForm').style.display = 'block'; 
        }

        function downloadCSV() {
            var filename = document.getElementById('filename').value || 'data_pengeluaran'; 
            var table = document.getElementById('dataTable');
            var rows = table.querySelectorAll('tr');

            var csvContent = "data:text/csv;charset=utf-8,";

            rows.forEach(function(row, index) {
                var columns = row.querySelectorAll('td, th'); 
                var rowArray = [];

                columns.forEach(function(column) {
                    rowArray.push(column.innerText); 
                });

                csvContent += rowArray.join(",") + "\r\n"; 
            });

            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", filename + ".csv");
            link.click();
        }

        function cancelCSV() {
            document.getElementById('csvForm').style.display = 'none';
        }

        function showCharts() {
            document.getElementById("charts").style.display = "block";
            document.querySelector("button[onclick='showCharts()']").style.display = "none";

            <?php

            $kategoriQuery = "SELECT kategori, SUM(jumlah) AS total FROM pengeluaran WHERE user_id = '$userId' GROUP BY kategori";
            $kategoriResult = mysqli_query($conn, $kategoriQuery);
            $kategoriData = [];
            $kategoriLabels = [];
            while ($row = mysqli_fetch_assoc($kategoriResult)) {
                $kategoriLabels[] = $row['kategori'];
                $kategoriData[] = (int) $row['total'];
            }

            $tanggalQuery = "SELECT tanggal, SUM(jumlah) AS total FROM pengeluaran WHERE user_id = '$userId' GROUP BY tanggal";
            $tanggalResult = mysqli_query($conn, $tanggalQuery);
            $tanggalData = [];
            $tanggalLabels = [];
            while ($row = mysqli_fetch_assoc($tanggalResult)) {
                $tanggalLabels[] = $row['tanggal'];
                $tanggalData[] = (int) $row['total'];
            }
            ?>

            var ctxPie = document.getElementById('pieChart').getContext('2d');
            var pieChart = new Chart(ctxPie, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode($kategoriLabels); ?>,
                    datasets: [{
                        label: 'Pengeluaran Berdasarkan Kategori',
                        data: <?php echo json_encode($kategoriData); ?>,
                        backgroundColor: ['#FF5733', '#33FF57', '#3357FF', '#F4F33D'],
                        borderColor: ['#FF5733', '#33FF57', '#3357FF', '#F4F33D'],
                        borderWidth: 1
                    }]
                }
            });

            var ctxBar = document.getElementById('barChart').getContext('2d');
            var barChart = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($tanggalLabels); ?>,
                    datasets: [{
                        label: 'Pengeluaran Berdasarkan Tanggal',
                        data: <?php echo json_encode($tanggalData); ?>,
                        backgroundColor: '#4caf50',
                        borderColor: '#4caf50',
                        borderWidth: 1
                    }]
                }
            });
        }


        function cancelGrafik() {
        document.getElementById("charts").style.display = 'none';

        const showChartButton = document.querySelector("button[onclick='showCharts()']");
        if (showChartButton) {
            showChartButton.style.display = 'inline-block';
        }
    }
    </script>

</body>
</html>