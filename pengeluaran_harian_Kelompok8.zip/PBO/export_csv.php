<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "pbo";
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$query = "SELECT * FROM pengeluaran";
$result = mysqli_query($conn, $query);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="pengeluaran.csv"');

$output = fopen('php://output', 'w');

fputcsv($output, ['Nama Pengeluaran', 'Kategori', 'Jumlah', 'Tanggal', 'Keterangan']);

while ($data = mysqli_fetch_assoc($result)) {
    fputcsv($output, $data);
}

fclose($output);
exit;
?>